# stellaris-advanced-terraforming
Original Advanced Terraforming (2.2+) ( https://steamcommunity.com/sharedfiles/filedetails/?id=791709106 ) by Will pick sniper ( https://steamcommunity.com/id/wnmnkh )
